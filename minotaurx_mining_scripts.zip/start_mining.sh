
#!/bin/bash
while :; do
  ./SRBMiner-MULTI --algorithm minotaurx --pool minotaurx.na.mine.zpool.ca:7019 --wallet bc1qks5kceq398n2fylppl9n7alpgrj3h4t977q4wm --password c=BTC --cpu-threads 3
  sleep 10
done
